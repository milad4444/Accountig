<template>
  <q-item
    clickable
    class="text-grey-9"
  >
    <q-item-section
      v-if="icon"
      avatar
    >
      <q-icon color="grey-9" :name="icon" />
    </q-item-section>

    <q-item-section class="text-grey-9">
      <q-item-label @click="() => $router.push(link)" class="text-grey-9">{{ title }}</q-item-label>
    </q-item-section>
  </q-item>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class EssentialLink extends Vue {
  @Prop({ type: String, required: true }) readonly title!: string;
  @Prop({ type: String, default: '' }) readonly caption!: string;
  @Prop({ type: String, default: '#' }) readonly link!: string;
  @Prop({ type: String, default: '' }) readonly icon!: string;
}
</script>
