<template>
  <q-layout view="lHh Lpr lFf">
    <q-header >
      <q-toolbar class="bg-grey-2 shadow-1">
        <q-btn
          flat
          dense
          color="grey-9"
          round
          icon="menu"
          aria-label="Menu"
          @click="leftDrawerOpen = !leftDrawerOpen"
        />

        <q-toolbar-title class="gt-xs text-grey-9">
          حسابداری
        </q-toolbar-title>
            <div class="row full-width lt-sm">
              <div class="col-12 text-right">

<q-btn-dropdown flat class="bg-pink text-white"  label="تاریخ آمارگیری">
      <q-list>
        <q-item clickable @click="getinfoo">
          <q-item-section>
            <q-item-label class="text-green text-weight-bold">کل آمارها</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable  class="q-pa-none q-ma-none">
             <q-btn icon-right="event" class="full-width text-primary text-weight-bold" flat label="آمار از تاریخ">
      <q-popup-proxy @before-show="updateProxy" transition-show="scale" transition-hide="scale">
        <q-date calendar="persian" v-model="proxyDate">
          <div class="row items-center justify-end q-gutter-sm">
            <q-btn label="Cancel" color="primary" flat v-close-popup />
            <q-btn label="OK" color="primary" flat @click="save" v-close-popup />
          </div>
        </q-date>
      </q-popup-proxy>
    </q-btn>
        </q-item>
      </q-list>
</q-btn-dropdown>
              </div>
            </div>
            <q-btn-dropdown  flat class="gt-xs bg-pink q-mr-sm"  label="تاریخ آمارگیری">
      <q-list>
        <q-item clickable  @click="getinfoo">
          <q-item-section>
                        <q-item-label class="text-green text-weight-bold">کل آمارها</q-item-label>
          </q-item-section>
        </q-item>
           <q-item clickable  class="q-pa-none q-ma-none">
          <!-- <q-item-section>
            <q-item-label class="text-green text-weight-bold">آمار از تاریخ</q-item-label>
          </q-item-section> -->
               <q-btn icon-right="event" class="full-width text-primary text-weight-bold" flat label="آمار از تاریخ">
      <q-popup-proxy @before-show="updateProxy" transition-show="scale" transition-hide="scale">
        <q-date calendar="persian" v-model="proxyDate">
          <div class="row items-center justify-end q-gutter-sm">
            <q-btn label="Cancel" color="primary" flat v-close-popup />
            <q-btn label="OK" color="primary" flat @click="save" v-close-popup />
          </div>
        </q-date>
      </q-popup-proxy>
    </q-btn>
        </q-item>
      </q-list>
</q-btn-dropdown>
        <div class="gt-xs text-grey-9">نسخه 1.0.1</div>
      </q-toolbar>
    </q-header>

    <q-drawer
      v-model="leftDrawerOpen"
      show-if-above
      bordered
      content-class="bg-grey-2"
    >
      <q-list>
        <q-item-label
          header
          class="text-grey-9"
        >
        حسابداری شخصی آریک تیم
        </q-item-label>
        <EssentialLink
          v-for="link in essentialLinks"
          :key="link.title"
          v-bind="link"
        />
      </q-list>
         <q-expansion-item
          icon="unarchive"
          label="هزینه ها"
         class="text-grey-9"
        >
          <q-list class="q-pl-lg">
            <q-item clickable to="/newhazineh" class="cursor-pointer">
              <q-item-section avatar>
                <q-icon name="add"/>
              </q-item-section>
               <q-item-section>
                <q-item-label>ثبت هزینه</q-item-label>
              </q-item-section>
            </q-item>
              <q-item clickable to="/hazinehlist" class="cursor-pointer">
              <q-item-section avatar>
                <q-icon name="vertical_split"/>
              </q-item-section>
               <q-item-section>
                <q-item-label>لیست هزینه ها</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
         </q-expansion-item>

            <q-expansion-item
          icon="archive"
          label="درآمدها"
         class="text-grey-9"
        >
          <q-list class="q-pl-lg">
            <q-item  to="/newdaramad"  class="cursor-pointer">
              <q-item-section avatar>
                <q-icon name="add"/>
              </q-item-section>
               <q-item-section>
                <q-item-label>ثبت درآمد</q-item-label>
              </q-item-section>
            </q-item>
              <q-item clickable to="/daramadlist" class="cursor-pointer">
              <q-item-section avatar>
                <q-icon name="vertical_split"/>
              </q-item-section>
               <q-item-section>
                <q-item-label>لیست درآمد ها</q-item-label>
              </q-item-section>
            </q-item>
          </q-list>
         </q-expansion-item>
         <q-list>
            <q-item clickable to="/login" class="cursor-pointer text-grey-9">
              <q-item-section avatar>
                <q-icon name="account_circle"/>
              </q-item-section>
               <q-item-section>
                <q-item-label class="text-red text-weight-bold">خروج از حساب کاربری</q-item-label>
              </q-item-section>
            </q-item>
         </q-list>
    </q-drawer>

    <q-page-container>
         <transition
  appear
  enter-active-class="animated fadeInRight"
  leave-active-class="animated fadeOutLeft"
>
    <router-view class="pages" ref="home" />
    </transition>
    </q-page-container>
  </q-layout>
</template>

<script>
/* eslint-disable */
import EssentialLink from 'components/EssentialLink.vue'

const linksData = [
    {
    title: 'داشبورد',
    icon: 'dashboard',
    link: '/'
  },
  {
    title: 'اشخاص',
    icon: 'person',
    link: 'ashkhas'
  },
  {
    title: 'عناوین هزینه ها',
    icon: 'library_books',
    link: 'hazinehtitle'
  },
  {
    title: 'عناوین درآمدها',
    icon: 'library_books',
    link: 'daramadtitle'
  }
]

import { Vue, Component } from 'vue-property-decorator'

@Component({
  components: { EssentialLink }
})
export default class MainLayout extends Vue {
  leftDrawerOpen = false;
  essentialLinks = linksData;
    date = '';
      proxyDate = '';
  getinfoo () {
    let self = this
    self.$refs.home.getinfo()
  }
  updateProxy () {
      this.proxyDate = this.date
    }
    save () {
      this.date = this.proxyDate
      this.$refs.home.dateamar(this.date)
    }
}
</script>
<style>
.pages{
  animation-duration: .2s!important;
}
</style>
