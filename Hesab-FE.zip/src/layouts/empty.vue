<template>
  <q-layout view="hHh Lpr fFf"> <!-- Be sure to play with the Layout demo on docs -->

    <!-- (Optional) The Header -->
    <q-header elevated>
    </q-header>
    <!-- (Optional) The Footer -->
    <!-- (Optional) A Drawer; you can add one more with side="right" or change this one's side -->
    <q-page-container>
      <!-- This is where pages get injected -->
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
export default {
  // name: 'LayoutName',

  data () {
    return {
    }
  }
}
</script>
