<template>
  <q-page>
    <div class="row justify-center full-width">
      <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
        <q-card bordered class="my-card">
             <q-tabs
          v-model="tab"
          class="bg-grey-3"
          align="justify"
          inline-label
          narrow-indicator
        >
          <q-tab name="contacts" icon="group" label="مخاطبین" />
          <q-tab name="new" @click="onReset" icon="add" label="مخاطب جدید" />
        </q-tabs>

<!--  new contact -->
 <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="new">
            <div class="row full-width">
              <div class="col-8 text-center">
             <q-btn flat class="text-grey-8 q-mt-lg" @click="choseimage" icon-right="add_a_photo" label="انتخاب عکس" />
              </div>
              <div class="col-4 text-right">

              <img v-if="mil4.length === 0" src="profile.svg" alt="" style="width:100px">
               <div v-if="mil4.length > 0" class="image_cover q-mb-sm q-ml-md">
              <img   class="company-header-avatar" :src="mil4" alt="" >
                  </div>
              </div>
            </div>
        <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md" >
        <q-input  dense color="amber" outlined v-model="name" label="نام" />
        <q-input  dense color="amber" outlined v-model="phone" label="شماره تلفن" />
        <q-input  dense color="amber" outlined v-model="address" label="آدرس" />
        <q-input  dense color="amber" outlined v-model="job" label="شغل" />
        <q-input  dense color="amber" outlined v-model="cart1" label=" شماره کارت 1" />
        <q-input  dense color="amber" outlined v-model="cart2" label=" شماره کارت 2" />
        <div>
        <q-btn label="ذخیره" flat type="submit" class="bg-amber text-white"/>
        <q-btn label="پاک سازی" type="reset" color="amber" flat class="q-ml-sm" />
        </div>
        </q-form>
          </q-tab-panel>
 </q-tab-panels>
<!--  /new contact -->

<!-- contacts -->
 <q-tab-panels class="lt-sm" v-if="selected_contact === null" v-model="tab" animated>
          <q-tab-panel name="contacts">
            <q-input rounded color="amber" dense outlined v-model="search" @keypress="oksearch" @keyup="oksearch"  label="جستجو ..." />
            <q-item @click="selectcon(con)" dense style="border-radius:50px" class="q-mt-sm" clickable v-for="con in contacts" :key="con + Math.random()" v-ripple>
      <q-item-section side>
           <img v-if="con.aks.length === 0" src="profile.svg" alt="" style="width:48px">
               <div v-if="con.aks.length > 0" class="image_cover1">
              <img   class="company-header-avatar1" :src="con.aks" alt="" >
                  </div>
      </q-item-section>
      <q-item-section>
        <q-item-label>{{con.name}}</q-item-label>
        <q-item-label caption>{{con.phone}}</q-item-label>
      </q-item-section>
      <q-item-section side>
             <q-btn dense round color="red" size="sm" text-color="white" icon="delete" @click="opendelete(con)" />
        </q-item-section>
    </q-item>
          </q-tab-panel>
 </q-tab-panels>

  <q-tab-panels class="gt-xs"  v-model="tab" animated>
          <q-tab-panel name="contacts">
            <q-input rounded color="amber" dense outlined v-model="search"  @keypress="oksearch" @keyup="oksearch" label="جستجو ..." />
            <q-item @click="selectcon(con)" dense style="border-radius:50px" class="q-mt-sm" clickable v-for="con in contacts" :key="con + Math.random()" v-ripple>
      <q-item-section side>
          <img v-if="con.aks.length === 0" src="profile.svg" alt="" style="width:48px">
               <div v-if="con.aks.length > 0" class="image_cover1">
              <img   class="company-header-avatar1" :src="con.aks" alt="" >
                  </div>
      </q-item-section>
      <q-item-section>
        <q-item-label>{{con.name}}</q-item-label>
        <q-item-label caption>{{con.phone}}</q-item-label>
      </q-item-section>
       <q-item-section side>
             <q-btn dense round color="red" size="sm" text-color="white" icon="delete" @click="opendelete(con)" />
        </q-item-section>
    </q-item>
          </q-tab-panel>
 </q-tab-panels>
<!-- /contacts -->

<!-- edit -->
<div v-if="selected_contact !== null" class="lt-sm">
  <div class="row full-width lt-sm">
              <div class="col-8 text-center">
             <q-btn flat class="text-grey-8 q-mt-lg" @click="choseimage" icon-right="add_a_photo" label="انتخاب عکس" />
              </div>
              <div class="col-4 text-right">

              <img v-if="mil4.length === 0" src="profile.svg" alt="" style="width:100px">
               <div v-if="mil4.length > 0" class="image_cover q-mb-sm q-ml-md">
              <img   class="company-header-avatar" :src="mil4" alt="" >
                  </div>
              </div>
            </div>
        <q-form @submit="edit" @reset="onReset" class="q-gutter-md" >
        <q-input  dense color="amber" outlined v-model="name" label="نام" />
        <q-input  dense color="amber" outlined v-model="phone" label="شماره تلفن" />
        <q-input  dense color="amber" outlined v-model="address" label="آدرس" />
        <q-input  dense color="amber" outlined v-model="job" label="شغل" />
        <q-input  dense color="amber" outlined v-model="cart1" label=" شماره کارت 1" />
        <q-input  dense color="amber" outlined v-model="cart2" label=" شماره کارت 2" />
        <div>
        <q-btn label="ویرایش" flat type="submit" class="bg-amber text-white"/>
        <q-btn label="انصراف" type="reset" color="amber" flat class="q-ml-sm" />
        </div>
        </q-form>
        </div>
<!-- /edit -->
        </q-card>
      </div>
      <div class="col-lg-7 col-md-7 col-sm-6 gt-xs">
        <q-card class="my-card" bordered v-if="selected_contact !== null">
        <div class="row full-width">
              <div class="col-8 text-center">
             <q-btn flat class="text-grey-8 q-mt-lg" @click="choseimage" icon-right="add_a_photo" label="انتخاب عکس" />
              </div>
              <div class="col-4 text-right">

              <img v-if="mil4.length === 0" src="profile.svg" alt="" style="width:100px">
               <div v-if="mil4.length > 0" class="image_cover q-mb-sm q-ml-md">
              <img   class="company-header-avatar" :src="mil4" alt="" >
                  </div>
              </div>
            </div>
        <q-form @submit="edit" @reset="onReset" class="q-gutter-md" >
        <q-input  dense color="amber" outlined v-model="name" label="نام" />
        <q-input  dense color="amber" outlined v-model="phone" label="شماره تلفن" />
        <q-input  dense color="amber" outlined v-model="address" label="آدرس" />
        <q-input  dense color="amber" outlined v-model="job" label="شغل" />
        <q-input  dense color="amber" outlined v-model="cart1" label=" شماره کارت 1" />
        <q-input  dense color="amber" outlined v-model="cart2" label=" شماره کارت 2" />
        <div>
        <q-btn label="ویرایش" flat type="submit" class="bg-amber text-white"/>
        <q-btn label="انصراف" type="reset" color="amber" flat class="q-ml-sm" />
        </div>
        </q-form>
        </q-card>
      </div>
    </div>

    <q-dialog v-model="deldialog" >
      <q-card>
        <q-card-section class="row items-center q-pb-none">
          <div class="text-h6 text-red">هشدار</div>
          <q-space />
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>

        <q-card-section>
          آیا از حذف این شخص مطمئن هستید ؟
        </q-card-section>
         <q-card-section>
               <q-btn flat @click="delshakhs" class="bg-red text-white text-weight-bold" label="بله" />
               <q-btn  flat color="red"  v-close-popup  label="خیر" />
        </q-card-section>
      </q-card>
    </q-dialog>

    <template>
        <image-compressor
          :done="getFiles"
          :scale="scale"
          style="display:none"
          :quality="quality"
          ref="compressor"
        >
        </image-compressor>
      </template>
       <q-btn color="white"   ref="pluss" @click="plus" style="display:none" text-color="#9B9B9B" label="Standard" />
  </q-page>
</template>

<script>
/* eslint-disable */
import imageCompressor from 'vue-image-compressor'
import Localbase from 'localbase'

const db = new Localbase('db')
export default {
  // name: 'PageName',
  data () {
    return {
      deldialog: false,
      search: '',
      quality: 10,
      scale: 100,
      compressed: [],
      originalSize: true,
      original: {},
      mil4: '',
      check: '',
      ch: 0,
      checkmil4: 0,
      tab: 'contacts',
      name: null,
      accept: null,
      phone: null,
      address: null,
      job: null,
      cart1: null,
      cart2: null,
      id: 0,
      contacts: [],
      selected_contact: null,
      logedinuser: {},
      prop: null
    }
  },
  components: { imageCompressor },
  created () {
    let self = this 
    db.collection('logedin').get().then(re => {
      if(re.length > 0){
        self.logedinuser = re[0]
        self.getinfo()
      } else {
        self.$router.push('login')
      }
    })
  },
  methods: {
    getinfo () {
      let self = this 
      db.collection('ashkhas').get().then(re =>{
      self.contacts = []
        re.forEach(function (ash){
          if(ash.user_id === self.logedinuser.id){
            self.contacts.push(ash)
          }
        })
      })
    },
    opendelete (con) {
      let self = this
      self.deldialog = true
      self.prop = con
    },
     delshakhs () {
      let self = this
      db.collection('ashkhas').doc({id: self.prop.id, user_id: self.logedinuser.id}).delete().then( re => {
        self.getinfo()
        self.deldialog = false
          self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'این شخص با موفقیت حذف شد',
              timeout: 1000
            })
      })
    },
    oksearch () {
      let self = this
      self.contacts = []
  db.collection('ashkhas').get().then(re =>{
        re.forEach(function (shakhs){
          if(shakhs.name.includes(self.search) && shakhs.user_id === self.logedinuser.id){
            self.contacts.push(shakhs)
          }
        })
      })
    },
    selectcon (con) {
      let self = this 
      self.selected_contact = con
      self.mil4 = con.aks
        self.name = con.name
      self.phone = con.phone
      self.address = con.address
      self.job = con.job
      self.cart1 = con.cart_1
      self.cart2 = con.cart_2
    },
    choseimage () {
      this.ch = 0
      const compressor = this.$refs.compressor.$el
      compressor.click()
    },
    removeimage () {
      const self = this
      self.compressed = []
      self.original = {}
      self.mil4 = ''
      self.aks = ''
    },
    getFiles (obj) {
      this.check = 80 + (Math.random() * 20)
      this.mil4 = obj.compressed.base64
      this.aks = obj.original.name
      console.log(obj.original.name)
    },
      plus () {
      let self = this
      self.quality = self.quality + 0.00001
    },
    edit () {
      let self = this
    db.collection('ashkhas').doc({id: self.selected_contact.id, user_id: self.logedinuser.id}).set({
        id: self.selected_contact.id,
        user_id: self.logedinuser.id,
        name: self.name,
        aks: self.mil4,
        phone: self.phone,
        address: self.address,
        job: self.job,
        cart_1: self.cart1,
        cart_2: self.cart2
      }).then(re => {
             self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'این شخص با موفقیت ویرایش شد',
              timeout: 1000
            })
        db.collection('ashkhas').get().then(resp => {
            self.contacts = []
          re.forEach(function (ash){
          if(ash.user_id === self.logedinuser.id){

            self.contacts.push(ash)
          }
        })
        })
      })
    },
    onSubmit () {
      let self = this
 db.collection('ashkhas').get().then(res => {
        self.id = res.length
           db.collection('ashkhas').add({
        id: res.length + 1,
        user_id: self.logedinuser.id,
        name: self.name,
        aks: self.mil4,
        phone: self.phone,
        address: self.address,
        job: self.job,
        cart_1: self.cart1,
        cart_2: self.cart2
      }).then(re => {
        self.onReset()
        self.tab = 'contacts'
             self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'این شخص با موفقیت ثبت شد',
              timeout: 1000
            })
            self.getinfo()
      //       self.contacts = []
      //   db.collection('ashkhas').get().then(resp => {
      //  re.forEach(function (ash){
      //     if(ash.user_id === self.logedinuser.id){

      //       self.contacts.push(ash)
      //     }
      //   })
      //   })
      })
      })
    },
    onReset () {
      let self = this
      self.selected_contact = null
      self.removeimage()
      self.name = null
      self.phone = null
      self.address = null
      self.job = null
      self.cart1 = null
      self.cart2 = null
    }
  },
  watch: {
      mil4: function (e) {
      let self = this
      self.checkmil4 = self.checkmil4 + 1
    },
    check: function (val) {
      let self = this
      if (self.ch !== 1) {
        self.plus()
        self.ch = 1
      }
    }
  }
}
</script>
<style>
.company-header-avatar{
    position: absolute;
     width: 100%;
      height: 100%;
       top: 0;
        left: 0;
        object-fit: cover;
        -webkit-object-fit: cover;
 }
 .image_cover{
   width:90px;
   height:90px;
   margin-top: 0px;
  text-align: center;
   position: relative;
   padding-bottom: 15%;
    -webkit-padding-bottom: 15%;
    border-radius: 50%;
     -webkit-border-radius: 50%;
     overflow: hidden;
 }
 .company-header-avatar1{
    position: absolute;
     width: 100%;
      height: 100%;
       top: 0;
        left: 0;
        object-fit: cover;
        -webkit-object-fit: cover;
 }
 .image_cover1{
   width:48px;
   height:48px;
   margin-top: 0px;
  text-align: center;
   position: relative;
   padding-bottom: 0%;
    -webkit-padding-bottom: 15%;
    border-radius: 50%;
     -webkit-border-radius: 50%;
     overflow: hidden;
 }
</style>
