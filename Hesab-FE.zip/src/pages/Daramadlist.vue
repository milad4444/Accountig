<template>
  <q-page>
      <q-toolbar class="text-grey-9 full-width bg-grey-3">
    <q-toolbar-title>
      لیست درآمد ها
    </q-toolbar-title>
    </q-toolbar>
    <div class="row full-width justify-center  q-mt-sm">
          <div class="col-lg-4 col-md-4 col-sm-6 col-xs-11">
            <div class="row full-width q-col-gutter-xs">
              <div class="col-4">
                 <q-btn flat @click="kol" class="bg-green full-width text-white text-weight-bold" no-wrap label="کل درآمد ها" />
              </div>
              <div class="col-4 text-center">
<q-btn flat  @click="daryafti" class="bg-amber text-white full-width text-weight-bold" label="دریافتی" />
              </div>
              <div class="col-4">
<q-btn flat @click="darentezar" class="bg-red text-white full-width text-weight-bold" no-wrap label="در انتظار دریافت" />
              </div>
            </div>
          </div>
    </div>
    <div class="row full-width justify-center  q-mt-sm">
      <div class="col-lg-md-sm-11 col-xs-12">

          <q-table :filter="filter" :data="data" :columns="columns" row-key="name" >
            <template v-slot:top>
        <q-input borderless dense class="bg-grey-2 full-width" v-model="filter" placeholder="جستجو ...">
          <template v-slot:append>
            <q-icon name="search" />
          </template>
        </q-input>
      </template>
        <template v-slot:body-cell-id="props">
        <q-td class="bg-green" v-if="props.row.full === true" :props="props">
          <p class="text-white q-pa-none q-ma-none">{{props.value}}</p>
        </q-td>
         <q-td class="bg-red" v-if="props.row.full !== true" :props="props">
           <p class="text-white q-pa-none q-ma-none">{{props.value}}</p>
        </q-td>
      </template>
       <template v-slot:body-cell-full="props">
         <q-td :props="props">
           <q-icon v-if="props.row.full === true" name="done"  class="bg-green text-white q-pa-xs" style="border-radius:50%" size="15px" />
           <q-icon  v-if="props.row.full !== true" name="close" class="bg-red text-white q-pa-xs"  style="border-radius:50%" size="15px" />
         </q-td>
       </template>
       <template v-slot:body-cell-edit="props">
         <q-td :props="props">
           <q-icon  name="edit"  @click="() => $router.push('editdaramad/' + props.value)" class="bg-amber text-white q-pa-xs" style="border-radius:50%" size="15px" />
           <q-icon   name="delete" @click="opendelete(props)" class="bg-red text-white q-pa-xs q-ml-sm"  style="border-radius:50%" size="15px" />
         </q-td>
       </template>
       <template v-slot:body-cell-zamimeh="props">
         <q-td :props="props">
           <q-icon  name="add" @click="() => $router.push('daramadzamimeh/' + props.value)"  class="bg-primary text-white q-pa-xs" style="border-radius:50%" size="15px" />
         </q-td>
       </template>
          </q-table>
      </div>
    </div>
    <!-- content -->
    <q-dialog v-model="deldialog" >
      <q-card>
        <q-card-section class="row items-center q-pb-none">
          <div class="text-h6 text-red">هشدار</div>
          <q-space />
          <q-btn icon="close" flat round dense v-close-popup />
        </q-card-section>

        <q-card-section>
          آیا از حذف این هزینه مطمئن هستید ؟
        </q-card-section>
         <q-card-section>
               <q-btn flat @click="deldaramad" class="bg-red text-white text-weight-bold" label="بله" />
               <q-btn  flat color="red"  v-close-popup  label="خیر" />
        </q-card-section>
      </q-card>
    </q-dialog>
       <q-page-sticky
      position="bottom-right"
      class="print-hide"
    >
      <q-fab
        class="q-ma-sm q-pa-none"
        icon="keyboard_arrow_right"
        size="20px"
        direction="left"
        color="dark"
      >
         <q-btn icon="event"  round color="amber">
      <q-popup-proxy  calendar="persian"  @before-show="updateProxy" transition-show="scale" transition-hide="scale">
        <q-date calendar="persian" v-model="proxyDate" color="amber">
          <div class="row items-center justify-end q-gutter-sm">
            <q-btn label="Cancel" color="primary" flat v-close-popup />
            <q-btn label="OK"  color="primary" flat @click="save" v-close-popup />
          </div>
        </q-date>
      </q-popup-proxy>
    </q-btn>
     <q-btn @click="since = true" round text-color="white" color="green" icon="linear_scale" />
      </q-fab>
       </q-page-sticky>

       <q-dialog v-model="since">
       <q-card>
       <q-card-section>
        <q-input filled v-model="date1" mask="date" dense label="از تاریخ">
      <template v-slot:append>
        <q-icon name="event" class="cursor-pointer">
          <q-popup-proxy ref="qDateProxy" transition-show="scale" transition-hide="scale">
            <q-date calendar="persian" v-close-popup v-model="date1">
              <div class="row items-center justify-end">
                <q-btn v-close-popup label="ok" color="primary" flat />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
        <q-input filled v-model="date2" mask="date" class="q-mt-xs" dense label="تا تاریخ">
      <template v-slot:append>
        <q-icon name="event" class="cursor-pointer">
          <q-popup-proxy ref="qDateProxy" v-close-popup transition-show="scale" transition-hide="scale">
            <q-date calendar="persian" v-close-popup v-model="date2">
              <div class="row items-center justify-end">
                <q-btn v-close-popup label="ok" color="primary" flat />
              </div>
            </q-date>
          </q-popup-proxy>
        </q-icon>
      </template>
    </q-input>
       </q-card-section>
       <q-card-actions align="right">
       <q-btn flat label="OK" @click="okdate" color="primary" v-close-popup />
       </q-card-actions>
       </q-card>
       </q-dialog>
  </q-page>
</template>

<script>
/* eslint-disable */
import Localbase from 'localbase'

const db = new Localbase('db')
export default {
  // name: 'PageName',
  data () {
    return {
      since: false,
      date: '',
      date1: '',
      date2: '',
      proxyDate: '',
      deldialog: false,
      filter: '',
        data: [],
        columns: [
           {
          name: 'id',
          required: true,
          label: 'ردیف',
          align: 'center',
          field: row => this.data.indexOf(row) + 1,
          format: val => `${val}`,
          sortable: true
        },
         {
          name: 'date',
          required: true,
          label: 'تاریخ',
          align: 'center',
          field: row => row.date,
          format: val => `${val}`,
          sortable: true
        },
          {
          name: 'title',
          required: true,
          label: 'عنوان درآمد',
          align: 'center',
          field: row => row.title,
          format: val => `${val}`,
          sortable: true
        },
         {
          name: 'explain',
          required: true,
          label: 'شرح',
          align: 'center',
          field: row => row.explain,
          format: val => `${val}`,
          sortable: true
        },
         {
          name: 'cash',
          required: true,
          label: 'مقدر هزینه',
          align: 'center',
          field: row => row.cash,
          format: val => `${val}`,
          sortable: true
        },
         {
          name: 'shakhs',
          required: true,
          label: 'طرف حساب',
          align: 'center',
          field: row => row.shakhs.label,
          format: val => `${val}`,
          sortable: true
        },
         {
          name: 'full',
          required: true,
          label: 'دریافتی کامل',
          align: 'center',
          field: row => row.full,
          format: val => `${val}`,
          sortable: true
        },
        {
          name: 'payedcash',
          required: true,
          label: 'مقدار دریافت شده',
          align: 'center',
          field: row => row.payedcash,
          format: val => `${val}`,
          sortable: true
        },
        {
          name: 'willpaycash',
          required: true,
          label: 'در انتظار دریافت',
          align: 'center',
          field: row => row.willpaycash,
          format: val => `${val}`,
          sortable: true
        },
        {
          name: 'edit',
          required: true,
          label: 'ویرایش',
          align: 'center',
          field: row => row.id,
          format: val => `${val}`,
          sortable: true
        },
        {
          name: 'zamimeh',
          required: true,
          label: 'ضمیمه',
          align: 'center',
          field: row => row.id,
          format: val => `${val}`,
          sortable: true
        },
        ],
        daramads: [],
        prop: [],
        logedinuser: {}
    }
  },
  created () {
    let self = this 
      db.collection('logedin').get().then(re => {
      if(re.length > 0){
        self.logedinuser = re[0]
        self.getinfo()
      } else {
        self.$router.push('login')
      }
    })
  },
  methods: {
     updateProxy () {
      this.proxyDate = this.date
    },

    save () {
       let self = this
        self.date = self.proxyDate
       self.data = []
      self.daramads.forEach(function (haz){
        if(self.date === haz.date){
          self.data.push(haz)
        }
      })
    },
    getinfo () {
      let self = this
      db.collection('daramads').get().then(re => {
      self.daramads = []
      self.data = []
         re.forEach(function (dar){
          if(dar.user_id === self.logedinuser.id){
            self.daramads.push(dar)
            self.data.push(dar)
          }
        })
      })
    },
    kol () {
      let self = this
      self.data = self.daramads
    },
    daryafti () {
      let self = this
      self.data = []
      self.daramads.forEach(function (haz){
        if(haz.full === true ){
        self.data.push(haz)
        }
      })
    },
    darentezar () {
  let self = this
      self.data = []
      self.daramads.forEach(function (haz){
        if(haz.full !== true ){
          self.data.push(haz)
        }
      })
    },
    opendelete (props) {
      let self = this
      self.deldialog = true
      self.prop = props
    },
    okdate () {
      let self = this
      self.data = []
      self.daramads.forEach(function (haz){
        if(self.date1 <= haz.date && self.date2 >= haz.date){
          self.data.push(haz)
        }
      })
    },
    deldaramad () {
      let self = this
      db.collection('daramads').doc({id: self.prop.row.id, user_id: self.logedinuser.id}).delete().then( re => {
        self.getinfo()
        self.deldialog = false
          self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'این هزینه با موفقیت حذف شد',
              timeout: 1000
            })
      })
    }
  }
}
</script>
