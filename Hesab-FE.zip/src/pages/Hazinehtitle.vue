<template>
  <q-page>
    <!-- content -->
    <div class="row justify-center full-width">
      <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
        <q-card bordered class="my-card">
             <q-tabs
          v-model="tab"
          class="bg-grey-3"
          align="justify"
          inline-label
          narrow-indicator
        >
          <q-tab name="titles" icon="group" label="عناوین هزینه ها" />
          <q-tab name="new" @click="onReset" icon="add" label="عنوان جدید" />
        </q-tabs>
<!--  new title -->
 <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="new">
        <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md" >
        <q-input  dense color="amber" outlined v-model="title" label="عنوان" />
        <div>
        <q-btn label="ذخیره" flat type="submit" class="bg-amber text-white"/>
        <q-btn label="پاک سازی" type="reset" color="amber" flat class="q-ml-sm" />
        </div>
        </q-form>
          </q-tab-panel>
 </q-tab-panels>
<!--  /new title -->

<!-- titles -->
<q-tab-panels v-if="selectedtitle === null" v-model="tab" animated>
          <q-tab-panel name="titles">
            <q-input rounded color="amber" dense outlined v-model="search"  @keypress="oksearch" @keyup="oksearch" label="جستجو ..." />
            <q-item @click="selecttitle(title)" dense style="border-radius:50px" class="q-mt-sm" clickable v-for="(title,index) in titles" :key="title + Math.random()" v-ripple>
      <q-item-section side>
           <q-btn flat icon-right="list" :label="index + 1" />
      </q-item-section>
      <q-item-section>
        <q-item-label>{{title.title}}</q-item-label>
      </q-item-section>
    </q-item>
          </q-tab-panel>
 </q-tab-panels>
<!-- /titles -->
<!-- edit -->
   <q-form v-if="selectedtitle !== null" @submit="edit" @reset="onReset" class="q-gutter-md" >
        <q-input  dense color="amber" outlined v-model="title" label="عنوان" />
        <div>
        <q-btn label="ویرایش" flat type="submit" class="bg-amber text-white"/>
        <q-btn label="حذف" flat @click="deletetitle" class="bg-red q-ml-sm text-white"/>
        <q-btn label="پاک سازی" type="reset" color="amber" flat class="q-ml-sm" />
        </div>
        </q-form>
<!-- /edit -->
        </q-card>
      </div>
    </div>
  </q-page>
</template>

<script>
/* eslint-disable */
import Localbase from 'localbase'

const db = new Localbase('db')
export default {
  // name: 'PageName',
  data () {
    return {
      tab: 'titles',
      title: null,
      id: 0,
      titles: [],
      selectedtitle: null,
      search: '',
      logedinuser: {}
    }
  },
  created () {
    let self = this 
      db.collection('logedin').get().then(re => {
      if(re.length > 0){
        self.logedinuser = re[0]
        self.getinfo()
      } else {
        self.$router.push('login')
      }
    })
  },
  methods: {
    selecttitle (title) {
        let self = this
        self.title = title.title
        self.selectedtitle = title
    },
    oksearch () {
      let self = this
      self.titles = []
  db.collection('hazinehtitles').get().then(re =>{
        re.forEach(function (title){
          if(title.title.includes(self.search) && title.user_id === self.logedinuser.id){
            self.titles.push(title)
          }
        })
      })
    },
onSubmit () {
      let self = this
 db.collection('hazinehtitles').get().then(res => {
        self.id = res.length
           db.collection('hazinehtitles').add({
        id: res.length + 1,
        user_id: self.logedinuser.id,
        title: self.title
      }).then(re => {
        self.tab = 'titles'
             self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'عنوان  با موفقیت ثبت شد',
              timeout: 1000
            })
            self.titles = []
        db.collection('hazinehtitles').get().then(resp => {
          resp.forEach(function (ht){
            if(ht.user_id === self.logedinuser.id){

              self.titles.push(ht)
            }
          })
        })
      })
      })
    },
    edit () {
  let self = this
    db.collection('hazinehtitles').doc({id: self.selectedtitle.id, user_id: self.logedinuser.id}).set({
        id: self.selectedtitle.id,
        title: self.title,
      }).then(re => {
        self.selectedtitle = null
             self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'این عنوان با موفقیت ویرایش شد',
              timeout: 1000
            })
            self.titles = []
        db.collection('hazinehtitles').get().then(resp => {
          resp.forEach(function (ht){
            if(ht.user_id === self.logedinuser.id){

              self.titles.push(ht)
            }
          })
        })
      })
    },
        onReset () {
      let self = this
      self.title = null
      self.selectedtitle = null
    },
    deletetitle () {
      let self = this
      db.collection('hazinehtitles').doc({ id: self.selectedtitle.id, user_id: self.logedinuser.id }).delete().then(re => {
         self.selectedtitle = null
             self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'این عنوان با موفقیت حذف شد',
              timeout: 1000
            })
            self.titles = []
          db.collection('hazinehtitles').get().then(resp => {
         resp.forEach(function (ht){
            if(ht.user_id === self.logedinuser.id){

              self.titles.push(ht)
            }
          })
        })
      })
    },
    getinfo () {
      let self = this 
      self.titles = []
      db.collection('hazinehtitles').get().then(re => {
         re.forEach(function (ht){
            if(ht.user_id === self.logedinuser.id){
              self.titles.push(ht)
            }
          })
      })
    }
  }
}
</script>
