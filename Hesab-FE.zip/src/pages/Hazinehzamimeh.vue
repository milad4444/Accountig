<template>
  <q-page>

      <div class="row q-pt-md q-col-gutter-md" style="width:100%">
        <div  class="col-lg-4 col-md-4 col-sm-6 col-xs-11">
          <div @click="choseimage" class="flex flex-center cursor-pointer" style="width:100%;height:300px;border:5px dashed grey">
             <q-btn flat color="grey-6" size="lg" icon="add" class="text-weight-bold"  label="اضافه کردن" />
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-11">
  <q-img
          :src="aks"
          style="width: 100%;max-height:300px"
          class="cursor-pointer"
        >
          <q-btn @click="hdelaks" class="absolute all-pointer-events cursor-pointer"  size="10px" round icon="delete" color="red" style="top:8px;left:5px">
            <q-tooltip>
              حذف عکس
            </q-tooltip>
          </q-btn>
            <q-btn   @click="fullaks" round class="absolute all-pointer-events cursor-pointer bg-blue" flat  text-color="white" icon="crop_free" style="bottom:10px;right:5px"/>
        </q-img>
        </div>
        <div v-for="(madrak,index) in madarek" :key="index" class="col-lg-4 col-md-4 col-sm-6 col-xs-11">
          <q-img
          :src="madrak.image"
          style="width: 100%;max-height:300px"
          class="cursor-pointer"
          native-context-menu
        >
          <q-btn @click="delaks(madrak)" class="absolute all-pointer-events cursor-pointer"  size="10px" round icon="delete" color="red" style="top:8px;left:5px">
            <q-tooltip>
              حذف عکس
            </q-tooltip>
          </q-btn>
          <div class="absolute-bottom text-subtitle1 text-center">
            {{madrak.title}}
          </div>
            <q-btn   @click="full(madrak)" round class="absolute all-pointer-events cursor-pointer bg-blue" flat  text-color="white" icon="crop_free" style="bottom:10px;right:5px"/>
        </q-img>
        </div>
      </div>

          <template>
        <image-compressor
          :done="getFiles"
          :scale="scale"
          style="display:none"
          :quality="quality"
          ref="compressor"
        >
        </image-compressor>
      </template>
       <q-btn color="white"   ref="pluss" @click="plus" style="display:none" text-color="black" label="Standard" />

    <q-dialog v-model="prompt" persistent>
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">عنوان مدرک انتخاب شده</div>
        </q-card-section>

        <q-card-section class="q-pt-none">
          <q-input dense placeholder="برای مثال: شناسنامه" v-model="name" autofocus @keyup.enter="savem" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat color="red" class="text-weight-bold" @click="() => prompt = false" label="منصرف شدم"    :loading="sub" >
            <template v-slot:loading>
              <q-spinner-facebook/>

            </template>
          </q-btn>
          <q-btn flat class="text-weight-bold" @click="savem" label="ذخیره"  :loading="sub" >
            <template v-slot:loading>
              <q-spinner-facebook/>

            </template>
          </q-btn>
        </q-card-actions>
      </q-card>
    </q-dialog>
    <q-dialog v-model="alert" full-width>
      <q-card style="width:auto">
      <q-card-section class="text-center">
         <img :src="aks1" alt="">
      </q-card-section>
      </q-card>

    </q-dialog>
  </q-page>
</template>

<script>
/* eslint-disable */
import Localbase from 'localbase'

const db = new Localbase('db')
import imageCompressor from 'vue-image-compressor'

export default {
  // name: 'PageName',
  data () {
    return {
      alert: false,
      quality: 30,
      scale: 100,
      compressed: [],
      originalSize: true,
      original: {},
      mil4: '',
      check: '',
      ch: 0,
      prompt: false,
      name: '',
      sub: false,
      madarek: [],
      aks: '',
      aks1: '',
      logedinuser: {}
    }
  },
  created () {
    let self = this
      db.collection('logedin').get().then(re => {
      if(re.length > 0){
        self.logedinuser = re[0]
        self.getinfo()
      } else {
        self.$router.push('login')
      }
    })
  },
  components: { imageCompressor },
  methods: {
    hdelaks () {
      let self = this
      db.collection('hazinehs').doc({id: self.$route.params.id * 1, user_id: self.logedinuser.id}).update({
        aks: ''
      }).then(re => {
        self.getinfo()
          self.$q.notify({
          icon: 'done_all',
          color: 'green-8',
          position: 'top',
          message: 'این ضمیمه حذف شد',
          timeout: 1000
        })
      })
    },
    delaks (madrak) {
      let self = this
        db.collection('hazinehzamimeh').doc({id: madrak.id, user_id: self.logedinuser.id}).delete().then(re => {
          self.getinfo()
            self.$q.notify({
          icon: 'done_all',
          color: 'green-8',
          position: 'top',
          message: 'این ضمیمه حذف شد',
          timeout: 1000
        })
        })
    },
    full (madrak) {
      let self = this
      self.alert = true
      self.aks1 = madrak.image
    },
    fullaks () {
 let self = this
      self.alert = true
      self.aks1 = self.aks
    },
    savem () {
      let self = this
      if (self.name.length > 0) {
        self.sub = true
        db.collection('hazinehzamimeh').get().then(res => {
        db.collection('hazinehzamimeh').add({
          id: res.length + 1,
          user_id: self.logedinuser.id,
          h_id: self.$route.params.id,
          image: self.mil4,
          title: self.name
        }).then(re => {
            self.sub = false
            self.prompt = false
            self.getinfo()
            self.name = ''
        }).catch(er => {
          self.prompt = false
          self.sub = false
          self.$q.notify({
            icon: 'report_problem',
            color: 'red-8',
            position: 'top',
            message: '  متأسفانه مشکلی پیش اومده ',
            timeout: 1000
          })
        })
        })
      } else {
        self.$q.notify({
          icon: 'report_problem',
          color: 'red-8',
          position: 'top',
          message: 'لطفا عنوان مدرک را مشخص کنید',
          timeout: 1000
        })
      }
    },
    choseimage () {
      this.ch = 0
      let compressor = this.$refs.compressor.$el
      compressor.click()
    },
    removeimage () {
      let self = this
      self.compressed = []
      self.original = {}
      self.mil4 = ''
      self.aks = ''
    },
    getFiles (obj) {
      this.check = 80 + (Math.random() * 20)
      this.mil4 = obj.compressed.base64
      this.aks = obj.original.name
      console.log(obj.original.name)
    },
    plus () {
      let self = this
      self.quality = self.quality + 0.00001
    },
    getinfo () {
      let self = this
      self.madarek = []
        db.collection('hazinehs').doc({id: self.$route.params.id * 1, user_id: self.logedinuser.id}).get().then(re => {
          self.aks = re.aks
        db.collection('hazinehzamimeh').get().then(res => {
          console.log(res)
          res.forEach(function (mad){
            if(mad.h_id ===  self.$route.params.id * 1 && mad.user_id === self.logedinuser.id){

              self.madarek.push(mad)
            }
          })
        })
        })
    }
  },
  watch: {
    check: function (val) {
      let self = this
      if (self.ch !== 1) {
        self.plus()
        self.ch = 1
      }
    },
    mil4: function (sal) {
      let self = this
      self.prompt = true
    }
  }
}
</script>

<style>
</style>
