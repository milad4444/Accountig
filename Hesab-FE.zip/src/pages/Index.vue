<template>
  <q-page>
         <q-card class="bg-transparent no-shadow no-border q-mt-sm">
      <q-card-section class="q-pa-none">
        <div class="row q-col-gutter-sm ">
          <div class="col-md-3 col-sm-12 col-xs-12">
            <q-item style="background-color: #5064b5" class="q-pa-none q-ml-xs">
              <q-item-section side style="background-color: #3e51b5" class=" q-pa-lg q-mr-none text-white">
                <q-icon name="person" color="white" size="24px"></q-icon>
              </q-item-section>
              <q-item-section class=" q-pa-md q-ml-none  text-white">
                <q-item-label class="text-white text-h6 text-weight-bolder">{{ashkhas.length}} نفر</q-item-label>
                <q-item-label>طرف حساب ها</q-item-label>
              </q-item-section>
            </q-item>
          </div>
          <div class="col-md-3 col-sm-12 col-xs-12">
            <q-item style="background-color: #f37169" class="q-pa-none q-ml-xs ">
              <q-item-section side style="background-color: #f34636" class=" q-pa-lg q-mr-none text-white">
                <q-icon name="north" size="24px"></q-icon>
              </q-item-section>
              <q-item-section class=" q-pa-md q-ml-none  text-white">
                <q-item-label class="text-white text-h6 text-weight-bolder">{{cash}}</q-item-label>
                <q-item-label>کل هزینه ها</q-item-label>
              </q-item-section>
            </q-item>
          </div>
          <div class="col-md-3 col-sm-12 col-xs-12">
            <q-item style="background-color: #ea6a7f" class="q-pa-none q-ml-xs">
              <q-item-section side style="background-color: #ea4b64" class=" q-pa-lg q-mr-none text-white">
                <q-icon name="south" size="24px"></q-icon>
              </q-item-section>
              <q-item-section class=" q-pa-md q-ml-none  text-white">
                <q-item-label class="text-white text-h6 text-weight-bolder">{{cash1}}</q-item-label>
                <q-item-label>کل درآمدها</q-item-label>
              </q-item-section>
            </q-item>
          </div>
          <div class="col-md-3 col-sm-12 col-xs-12">
            <q-item style="background-color: #a270b1" class="q-pa-none q-ml-xs q-mr-xs">
              <q-item-section side style="background-color: #9f52b1" class=" q-pa-lg q-mr-none text-white">
                <q-icon name="bar_chart" size="24px"></q-icon>
              </q-item-section>
              <q-item-section class=" q-pa-md q-ml-none  text-white">
                <q-item-label class="text-white text-h6 text-weight-bolder">{{cash2}}</q-item-label>
                <q-item-label>ما باقی</q-item-label>
              </q-item-section>
            </q-item>
          </div>
        </div>
      </q-card-section>
    </q-card>

       <money
                    class="money"
                    v-model="cash"
                    v-bind="money"
                    color="amber"
                    style="display:none;background:#fafafa;width:100%;border:1px solid #bdbdbd;height:40px;border-radius:5px;direction:ltr;font-weight:900;padding-left:5px"
                  ></money>
                     <money
                    class="money"
                    v-model="cash1"
                    v-bind="money"
                    color="amber"
                    style="display:none;background:#fafafa;width:100%;border:1px solid #bdbdbd;height:40px;border-radius:5px;direction:ltr;font-weight:900;padding-left:5px"
                  ></money>
                       <money
                    class="money"
                    v-model="cash2"
                    v-bind="money"
                    color="amber"
                    style="display:none;background:#fafafa;width:100%;border:1px solid #bdbdbd;height:40px;border-radius:5px;direction:ltr;font-weight:900;padding-left:5px"
                  ></money>
  </q-page>
</template>

<script>
/* eslint-disable */
import Localbase from 'localbase'

const db = new Localbase('db')
import { Money } from 'v-money'
export default {
  components: { Money },
  data () {
    return {
      ashkhas: [],
      hazinehs: 0,
      cash: 0,
      cash1: 0,
      cash2: 0,
        money: {
        decimal: ',',
        thousands: ',',
        prefix: ' تومان ' + ' ',
        suffix: '',
        precision: 0,
        masked: true
      },
      daramads: 0,
      baghi: 0,
      logedinuser: {}
    }
  },
  created () {
    let self =  this
      db.collection('logedin').get().then(re => {
      if(re.length > 0){
        self.logedinuser = re[0]
        self.getinfo()
      } else {
        self.$router.push('login')
      }
    })
  },
  methods: {
    getinfo() {
      let self = this
   db.collection('ashkhas').get().then(res => {
       self.ashkhas = []
      self.hazinehs = 0
      self.cash = 0
      self.cash1 = 0
      self.cash2 = 0
      self.daramads = 0
      self.baghi = 0
     res.forEach(function (ash){
       if(ash.user_id === self.logedinuser.id){
         self.ashkhas.push(ash)
       }
     })
        // self.ashkhas = res
        db.collection('hazinehs').get().then(re => {
          re.forEach(function (haz){
            if(haz.user_id === self.logedinuser.id){

              self.hazinehs = self.hazinehs + (haz.cash.replace(/[^0-9]/g, "") * 1)
            }
          })
        db.collection('daramads').get().then(dar => {
          if(dar.length > 0){
 dar.forEach(function (daramad){
            if(daramad.user_id === self.logedinuser.id){
              self.daramads = self.daramads + (daramad.cash.replace(/[^0-9]/g, "") * 1)
              self.baghi = self.daramads * 1 - self.hazinehs * 1
            }
          })
          } else {
              self.baghi = self.daramads  - self.hazinehs * 1
          }
         
        })
        })
      })
    },
    dateamar (date) {
      let self = this
       self.ashkhas = []
      self.hazinehs = 0
      self.cash = 0
      self.cash1 = 0
      self.cash2 = 0
      self.daramads = 0
      self.baghi = 0
   db.collection('ashkhas').get().then(res => {
      res.forEach(function (ash){
       if(ash.user_id === self.logedinuser.id){
         self.ashkhas.push(ash)
       }
     })
        // self.ashkhas = res
        db.collection('hazinehs').get().then(re => {
          re.forEach(function (haz){
            if(haz.date >= date && haz.user_id === self.logedinuser.id) {

              self.hazinehs = self.hazinehs + (haz.cash.replace(/[^0-9]/g, "") * 1)
            }
          })
        db.collection('daramads').get().then(dar => {
          if(dar.length > 0){

            dar.forEach(function (daramad){
              if(daramad.date >= date && daramad.user_id === self.logedinuser.id) {
  
              self.daramads = self.daramads + (daramad.cash.replace(/[^0-9]/g, "") * 1)
              self.baghi = self.daramads * 1 - self.hazinehs * 1
              }
            })
          } else {
            self.baghi = self.daramads  - self.hazinehs * 1
          }
        })
        })
      })
    }
  },
  watch: {
    hazinehs () {
      let self =  this
      self.cash = self.hazinehs
    },
        daramads () {
      let self =  this
      self.cash1 = self.daramads
    },
    baghi () {
      let self = this
      self.cash2 = self.baghi
    }
  }
}
</script>
