<template>
      <q-page class="bg-image">
        <!-- <q-card v-bind:style="$q.screen.lt.sm?{'width': '80%'}:{'width':'50%'}"> -->
          <div class="row full-width justify-center q-pt-xl">
          <div class="col-lg-4 col-md-4 col-sm-6 col-xs-11 text-center">
                   <transition
  appear
  enter-active-class="animated fadeInRight"
  leave-active-class="animated fadeOutLeft"
>
          <q-card class="card" style="border-radius:10px">
          <q-card-section>
            <q-avatar size="103px" class="absolute-center shadow-10">
              <img src="profile.svg">
            </q-avatar>
          </q-card-section>
          <q-card-section>
            <div class="text-center q-pt-lg">
              <div class="col text-h6 ellipsis text-weight-bolder">
              ورود به نرم افزار حسابداری آریک تیم
              </div>
            </div>
          </q-card-section>
          <q-card-section>
            <q-form
              class="q-gutter-md"
            >
              <q-input
                filled
                v-model="username"
                label="Username"
                lazy-rules
              />
              <q-input
                type="password"
                filled
                v-model="password"
                label="Password"
                lazy-rules
                @keypress.enter="signin"
              />

              <div>
                <q-btn label="ورود" :loading="submiting" color="dark" @click="signin">
                  <template v-slot:loading>
                  <q-spinner-facebook color="white"  />
                </template>
                </q-btn>
                <q-btn label="ثبت نام"  class="q-ml-sm"  :loading="submiting" color="dark" @click="signup">
                <template v-slot:loading>
                  <q-spinner-facebook color="white"  />
                </template>
                </q-btn>
              </div>
            </q-form>
          </q-card-section>
        </q-card>
                   </transition>
        </div>
        </div>
      </q-page>
</template>

<script>
/* eslint-disable */
import Localbase from 'localbase'

const db = new Localbase('db')
export default {
        data() {
            return {
                username: '',
                password: '',
                submiting: false,
                id: 0,
                users: [],
                login: 0
            }
        },
        methods: {
          getinfo () {
    db.collection('user').get().then(res => {
        this.id = res.length
      })
          },
          signup() {
            const self = this 
            const passwordHash = require('password-hash')
            self.submiting = true
             db.collection('user').add({
        id: self.id + 1,
        name: self.username,
        password: passwordHash.generate(self.password)
      }).then(re => {
        self.getinfo()
                 self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'کاربر با موفقیت ثبت نام شد',
              timeout: 1000
            })
            self.username = ''
            self.password = ''
            self.submiting = false
            })
          },
          signin () {
            let self = this
            self.login = 0
            db.collection('logedin').delete()
            const passwordHash = require('password-hash');
          db.collection('user').get().then(res => {
            res.forEach(function (user){

              if(passwordHash.verify(self.password, user.password) === true && user.name === self.username){ 
                db.collection('logedin').add({
                  id: user.id,
                  name: user.name,
                  password: user.password
                }).then(mes => {
                    db.collection('ashkhas').get().then(ash => {
                      ash.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('ashkhas').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })
                       db.collection('daramads').get().then(dar => {
                      dar.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('daramads').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                      db.collection('daramadtitles').get().then(dart => {
                      dart.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('daramadtitles').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('daramadzamimeh').get().then(darz => {
                      darz.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('daramadzamimeh').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('hazinehs').get().then(haz => {
                      haz.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('hazinehs').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('hazinehtitles').get().then(hazt => {
                      hazt.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('hazinehtitles').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('hazinehzamimeh').get().then(hazz => {
                      hazz.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('hazinehzamimeh').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })
                  self.$q.notify({
               icon: 'done_all',
               color: 'green-8',
               position: 'center',
               message: user.name + ' ' + 'خوش آمدید',
               timeout: 1000
             })
             self.login = 1
             self.$router.push('/')
             return true
                }).catch(er => {
                      db.collection('logedin').add({
                  id: user.id,
                  name: user.name,
                  password: user.password
                }).then(mes => {

db.collection('ashkhas').get().then(ash => {
                      ash.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('ashkhas').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                       db.collection('daramads').get().then(dar => {
                      dar.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('daramads').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                      db.collection('daramadtitles').get().then(darmt => {
                      darmt.forEach(function (objes){
                        if(!objes.user_id){
                          db.collection('daramadtitles').doc({id: objes.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('daramadzamimeh').get().then(darz => {
                      darz.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('daramadzamimeh').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('hazinehs').get().then(haz => {
                      haz.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('hazinehs').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('hazinehtitles').get().then(hazt => {
                      hazt.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('hazinehtitles').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })

                     db.collection('hazinehzamimeh').get().then(hazz => {
                      hazz.forEach(function (obje){
                        if(!obje.user_id){
                          db.collection('hazinehzamimeh').doc({id: obje.id}).update({
                            user_id: user.id
                          })
                        }
                      })
                    })
                  self.$q.notify({
               icon: 'done_all',
               color: 'green-8',
               position: 'center',
               message: user.name + ' ' + 'خوش آمدید',
               timeout: 1000
             })
             self.login = 1
             self.$router.push('/')
             return true
                })
                })
              }
            })
            setTimeout(function () { self.goerror() }, 100)
               
          })
          },
        goerror () {
          let self = this
          if(self.login === 0){
            self.$q.notify({
                icon: 'report_problem',
               color: 'red-8',
               position: 'center',
               message: 'نام کاربری یا رمز ورود صحیح می باشد',
               timeout: 1000
            })
          }
        }
        },
        created () {
        const self = this 
        self.getinfo()
        }
    }
</script>

<style>

  .bg-image {
   background-image: linear-gradient(135deg, #7028e4 0%, #e5b2ca 100%);
  }
  .card{
    animation-duration: 1s;
  }
</style>
