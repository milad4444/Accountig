<template>
  <q-page>
    <q-toolbar class="text-grey-9 bg-grey-3">
    <q-toolbar-title>
    ثبت درآمد جدید
    </q-toolbar-title>
    </q-toolbar>
    <!-- content -->
    <div class="row full-width  q-col-gutter-xs q-mt-sm q-mb-md">
      <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
          <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >عنوان درآمد</p>
        <q-select dense outlined color="amber" behavior="menu" v-model="daramadtitle" :options="daramadtitles" label="انتخاب" />
      </div>
      <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
          <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >انتخاب طرف حساب</p>
        <q-select dense outlined color="amber" behavior="menu" v-model="shakhs" :options="ashkhas" label="انتخاب" />
      </div>
      <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
          <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >شرح</p>
                  <q-input  outlined dense v-model="explain" />
      </div>
      <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">

       <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >مقدار درآمد</p>
                  <money
                    class="money"
                    v-model="cash"
                    v-bind="money"
                    color="amber"
                    style="background:#fafafa;width:100%;border:1px solid #bdbdbd;height:40px;border-radius:5px;direction:ltr;font-weight:900;padding-left:5px"
                  ></money>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
          <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >دریافت کامل درآمد</p>
        <q-checkbox v-model="full" />
      </div>
      <div v-if="full !== true" class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
         <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >دریافت انجام شده</p>
                  <money
                    class="money"
                    v-model="payedcash"
                    v-bind="money"
                    color="amber"
                    style="background:#fafafa;width:100%;border:1px solid #bdbdbd;height:40px;border-radius:5px;direction:ltr;font-weight:900;padding-left:5px"
                  ></money>
      </div>
       <div v-if="full !== true" class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
         <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >مقدار در انتظار دریافت</p>
                  <money
                    class="money"
                    v-model="willpaycash"
                    v-bind="money"
                    color="amber"
                    style="background:#fafafa;width:100%;border:1px solid #bdbdbd;height:40px;border-radius:5px;direction:ltr;font-weight:900;padding-left:5px"
                  ></money>
      </div>
       <div  class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >تاریخ</p>
          <q-date
      v-model="date"
      calendar="persian"
      class=""
      today-btn
      color="amber"
    />
       </div>
       <div  class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
    <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >ضمیمه عکس</p>
                 <q-btn outline @click="choseimage" class="text-green" icon="add"/>
       </div>
          <div v-if="mil4.length > 0" class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
    <p
                    class="text-weight-bold text-blue-grey-6"
                    style="margin:0;font-size:18px"
                  >عکس ها</p>
                  <div v-if="mil4.length > 0" class="image_cover">
              <img   class="company-header-avatar" :src="mil4" alt="" >
                  </div>
       </div>
    </div>
          <!-- <div class="row full-width justify-center">

          <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 ">

          </div>
          </div> -->
          <q-page-sticky
      position="bottom-right"
      :offset="[18, 18]"
      class="print-hide text-center"
    >
     <q-btn  @click="savedaramad" rounded icon="save" class="bg-green-6 text-white  text-weight-bold  q-mb-xs" label="ذخیره درآمد" />
          </q-page-sticky>
     <template>
        <image-compressor
          :done="getFiles"
          :scale="scale"
          style="display:none"
          :quality="quality"
          ref="compressor"
        >
        </image-compressor>
      </template>
       <q-btn color="white"   ref="pluss" @click="plus" style="display:none" text-color="#9B9B9B" label="Standard" />
  </q-page>
</template>

<script>
/* eslint-disable */
import Localbase from 'localbase'

const db = new Localbase('db')
import { Money } from 'v-money'
import imageCompressor from 'vue-image-compressor'


export default {
  
  // name: 'PageName',
  components: { Money, imageCompressor },
  data () {
    return {
      text: '',
      quality: 10,
      scale: 100,
      compressed: [],
      originalSize: true,
      original: {},
      mil4: '',
      check: '',
      ch: 0,
      checkmil4: 0,
      date: '',
      daramads: [],
      daramadtitles: [],
      daramadtitle: null,
      ashkhas: [],
      shakhs: null,
      explain: null,
      cash: null,
      full: true,
      payedcash: null,
      willpaycash: null,
       money: {
        decimal: ',',
        thousands: ',',
        prefix: ' تومان ' + ' ',
        suffix: '',
        precision: 0,
        masked: true
      },
      logedinuser: {}
    }
  },
  created () {
    let self = this
      db.collection('logedin').get().then(re => {
      if(re.length > 0){
          self.logedinuser = re[0]
        self.getinfo()
      } else {
        self.$router.push('login')
      }
    })
  },
  methods: {
    getinfo () {
      let self = this
      self.daramadtitles = []
      self.ashkhas = []
  db.collection('daramadtitles').get().then(re => {
    re.forEach(function (title){
      if(title.user_id === self.logedinuser.id){

        self.daramadtitles.push(title.title)
      }
    })
  })
  db.collection('ashkhas').get().then(re => {
     re.forEach(function (shakhs){
      if(shakhs.user_id === self.logedinuser.id){

        self.ashkhas.push({label: shakhs.name, value:shakhs.id})
      }
    })
  })
    },
    savedaramad () {
      let self = this
      if(self.shakhs !== null && self.daramadtitle !== null && self.cash !== null && self.date.length > 0 && self.full === true){

        db.collection('daramads').get().then(re => {
          db.collection('daramads').add({
            id: re.length + 1,
            user_id: self.logedinuser.id,
            title: self.daramadtitle,
            shakhs: self.shakhs,
            cash: self.cash,
            explain: self.explain,
            full: self.full,
            payedcash: self.payedcash,
            willpaycash: self.willpaycash,
            aks: self.mil4,
            date: self.date
          }).then(res => {
            self.onReset()
                self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'درآمد با موفقیت ثبت شد',
              timeout: 1000
            })
          })
        })
      } else if (self.shakhs !== null && self.daramadtitle !== null && self.cash !== null && self.date.length > 0 && self.full !== true) {
        if(self.payedcash !== null){
          
        db.collection('daramads').get().then(re => {
          db.collection('daramads').add({
            id: re.length + 1,
            user_id: self.logedinuser.id,
            title: self.daramadtitle,
            shakhs: self.shakhs,
            cash: self.cash,
            explain: self.explain,
            full: self.full,
            payedcash: self.payedcash,
            willpaycash: self.willpaycash,
            aks: self.mil4,
            date: self.date
          }).then(res => {
            self.onReset()
                self.$q.notify({
              icon: 'done_all',
              color: 'green-8',
              position: 'center',
              message: 'درآمد با موفقیت ثبت شد',
              timeout: 1000
            })
          })
        })
        } else {
          self.$q.notify({
              icon: 'report_problem',
              color: 'red-8',
              position: 'center',
              message: 'لطفا اطلاعات خود را کامل کنید',
              timeout: 1000
            })
        }
      } else {
           self.$q.notify({
              icon: 'report_problem',
              color: 'red-8',
              position: 'center',
              message: 'لطفا اطلاعات خود را کامل کنید',
              timeout: 1000
            })
      }
    },
    onReset() {
      let self = this
      self.shakhs = null
      self.daramadtitle = null
      self.cash = 0
      self.date = ''
      self.payedcash = null
      self.willpaycash = null
      self.explain = null
      self.compressed = []
      self.original = {}
      self.mil4 = ''
      self.aks = ''
    },
     choseimage () {
      this.ch = 0
      const compressor = this.$refs.compressor.$el
      compressor.click()
    },
    removeimage () {
      const self = this
      self.compressed = []
      self.original = {}
      self.mil4 = ''
      self.aks = ''
    },
    getFiles (obj) {
      this.check = 80 + (Math.random() * 20)
      this.mil4 = obj.compressed.base64
      this.aks = obj.original.name
      console.log(obj.original.name)
    },
      plus () {
      let self = this
      self.quality = self.quality + 0.00001
    },
  },
  watch: {
    full() {
      let self= this
        self.payedcash = null
        self.willpaycash = null
    },
      mil4: function (e) {
      let self = this
      self.checkmil4 = self.checkmil4 + 1
    },
    check: function (val) {
      let self = this
      if (self.ch !== 1) {
        self.plus()
        self.ch = 1
      }
    },
    payedcash () {
      let self = this
      self.willpaycash = self.cash.replace(/[^0-9]/g, "") - self.payedcash.replace(/[^0-9]/g, "")
    }
  }
}
</script>
<style>
.company-header-avatar{
    position: absolute;
     width: 100%;
      height: 100%;
       top: 0;
        left: 0;
        object-fit: cover;
        -webkit-object-fit: cover;
 }
 .image_cover{
   width:150px;
   height:150px;
   margin-top: 0px;
  text-align: center;
   position: relative;
   padding-bottom: 15%;
    -webkit-padding-bottom: 15%;
    border-radius: 5px;
     -webkit-border-radius: 5px;
     overflow: hidden;
 }
</style>
