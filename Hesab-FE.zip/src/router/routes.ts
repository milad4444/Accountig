import { RouteConfig } from 'vue-router'

const routes: RouteConfig[] = [
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Index.vue') },
      { path: 'ashkhas', component: () => import('pages/Ashkhas.vue') },
      { path: 'hazinehtitle', component: () => import('pages/Hazinehtitle.vue') },
      { path: 'daramadtitle', component: () => import('pages/Daramadtitle.vue') },
      { path: 'newhazineh', component: () => import('pages/Newhazineh.vue') },
      { path: 'newdaramad', component: () => import('pages/Newdaramad.vue') },
      { path: 'hazinehlist', component: () => import('pages/Hazinehlist.vue') },
      { path: 'daramadlist', component: () => import('pages/Daramadlist.vue') },
      { path: 'edithazineh/:id*/', component: () => import('pages/edithazineh.vue') },
      { path: 'editdaramad/:id*/', component: () => import('pages/edithazineh.vue') },
      { path: 'hazinehzamimeh/:id*/', component: () => import('pages/Hazinehzamimeh.vue') },
      { path: 'daramadzamimeh/:id*/', component: () => import('pages/Daramadzamimeh.vue') }
    ]
  },
  {
    path: '/login',
    component: () => import('layouts/empty.vue'),
    children: [
      { path: '', component: () => import('pages/Login.vue') }
    ]
  },

  // Always leave this as last one,
  // but you can also remove it
  {
    path: '*',
    component: () => import('pages/Error404.vue')
  }
]

export default routes
