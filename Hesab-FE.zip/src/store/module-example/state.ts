export interface ExampleStateInterface {
  prop: boolean;
}

const state: ExampleStateInterface = {
  prop: false
}

export default state
